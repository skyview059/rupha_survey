<section class="content-header">
    <h1>@Maintenance Mode!</h1>
</section>

<section class="content" style="min-height: 100px;">
    <p class="ajax_error">DO NOT MAKE ANY CHANGES</p>
</section>