<div class="containter text-center">                
    <h1><?php echo getSettingItem('ComName'); ?></h1>
    <hr/>
    <h3 style="color: #c82400;">404 Page Not Found</h3>
    <h4>
        <a href="<?php echo site_url(); ?>">
            &NestedLessLess;
            Back to Dashboard
        </a> 
    </h4>
</div>