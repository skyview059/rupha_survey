<section class="content-header">
    <h1>Access Denied!</h1>
</section>

<section class="content">
    <p class="ajax_error">You do not have access to this page </p>
</section>