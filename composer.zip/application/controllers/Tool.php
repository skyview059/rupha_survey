<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tool extends Admin_controller {
    // every thing coming form Frontend Controller        
    
    
}