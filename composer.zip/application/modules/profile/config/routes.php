<?php

$route['admin/profile']              = 'profile';
$route['admin/profile/index']        = 'profile/index';
$route['admin/profile/business']     = 'profile/business';
$route['admin/profile/business_update']     = 'profile/business_update';
$route['admin/profile/update']       = 'profile/update';
$route['admin/profile/password']     = 'profile/password';
$route['admin/profile/update_password']     = 'profile/update_password';
