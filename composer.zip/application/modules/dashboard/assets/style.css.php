<style type="text/css">
    .text-middle {
        vertical-align: middle !important;
        text-align: center;
    }
    
    .tx-rec { background-color: #dff0d8; text-align: right; }
    .tx-pay { background-color: #f0ddd8; text-align: right; }
    .tx-total { background-color: #fffde7; text-align: right; }
</style>    
